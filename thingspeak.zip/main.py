import RPi.GPIO as GPIO 
import dht11
import http.client, urllib.request, urllib.parse


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

pin=dht11.DHT11(pin=3)

while(True):
    t=pin.read()
    if t.is_valid():
        print("Temperature : ",t.temperature)
        print("Humidity : ",t.Humidity)
        
        params=urllib.parse.urlencode({'field1':t.temperature,"field2":t.Humidity})
        
        headers={"Content-typZZe":"application/x-www-form-urlencoded","Accept":"text/plain"}
        
        con=http.client.HTTPConnection("api.thingspeak.com")
        
        con.request("POST","/update",params,headers)
        
        responce=con.getresponse()
        
        print(responce.status,response.reason)
        
        data=response.read()
        