import RPi.GPIO as GPIO
import dht11
GPIO.setmode(GPIO.BOARD)

GPIO.setwarnings(false)

GPIO.setup(38,GPIO.OUT)

pin=dht11.DHT11(pin=3)

while true:
    t=pin.read()
    if t.is_valid():
        print("Temperature :  ",t.teperature)
        print("Humidity : ",t.humidity)
        
        if(t.teperature>=28):
            print("High teperature ")
            GPIO.output(38,GPIO.HIGH)
            
            

