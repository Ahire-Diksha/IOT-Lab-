import RPi.GPIO as GPIO
import time
import sys
import os 

os.system('clear')
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(false)

GPIO.setup(28,GPIO.IN)

while True:
    i=GPIO.input(28)
    if(i==1):
        print("obstacle")
        os.system("fswebcam /home/pi/Desktop/new.jpg")
        break
    else:
        print("No obstacle")
        
