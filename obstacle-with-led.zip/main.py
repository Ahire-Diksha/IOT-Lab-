import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(false)
GPIO.setup(38,GPIO.IN)

GPIO.setup(35,GPIO.OUT)

while true:
    i=GPIO.input(38)
    if(i==1):
        print("Obstacle")
        GPIO.output(35,GPIO.HIGH)
    else:
        print("No Obstacle ")
        GPIO.output(35,GPIO.LOW)